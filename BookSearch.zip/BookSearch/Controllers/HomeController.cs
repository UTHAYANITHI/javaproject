﻿using BookSearch.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Net;
using System.Reflection.Metadata.Ecma335;

namespace BookSearch.Controllers
{

    public class HomeController : Controller
    {


        private IConfiguration _config;

        public HomeController(IConfiguration config)
        {
            _config = config;



        }

        public IActionResult Index()
        {
            return View();
        }


        [HttpGet]
        [Route("/api/book-search")]
        public async Task<IActionResult> Index(string isbn, string key)

        {

            string keyvalue = _config["key"];

            if (key == keyvalue)
            {
                var book = await GetBookData(isbn);

                if (book != null)
                {
                    return View(book);
                }
            }
            else
            {
                ViewBag.ErrorMessage = "Invalid Key";
                return View("Index");
            }

            ViewBag.ErrorMessage = "Sorry, we could not find any information about this book.";
            return View("Index");
        }

        private async Task<Book> GetBookData(string isbn)
        {
            string settingValue = _config["apikey"];
            //bookie
            var bookieUrl = $"https://lspl-bookie.glitch.me/books/{isbn}/details?key={settingValue}";

            var bookieResponse = await new HttpClient().GetAsync(bookieUrl);

            var bookieData = await bookieResponse.Content.ReadAsStringAsync();

            //info4you
            var info4youUrl = $"https://lspl-info4you.glitch.me/search?isbn={isbn}";

            var info4youResponse = await new HttpClient().GetAsync(info4youUrl);

            var info4youData = await info4youResponse.Content.ReadAsStringAsync();

            if (bookieResponse.StatusCode == HttpStatusCode.Unauthorized)
            {
                ViewBag.ErrorMessage = "Invalid API Key";
                return null;
            }

            if (!string.IsNullOrEmpty(bookieData) && bookieData != "{}")
            {
                var book = JsonConvert.DeserializeObject<Book>(bookieData);
                return book;
            }
            else if (!string.IsNullOrEmpty(info4youData))
            {
                var responseObject = JsonConvert.DeserializeObject<dynamic>(info4youData);
                var id = responseObject.ID;
                var success = responseObject.Success;

                var bookDetailsUrl = $"https://lspl-info4you.glitch.me/info/{id}";
                var bookDetailsResponse = await new HttpClient().GetAsync(bookDetailsUrl);

                var info4youDataa = await bookDetailsResponse.Content.ReadAsStringAsync();

                if (!string.IsNullOrEmpty(info4youDataa) && success == true && info4youData != "{}")
                {
                    var book = JsonConvert.DeserializeObject<Book>(info4youDataa);
                    return book;
                }
            }

            return null;
        }
    }
}

