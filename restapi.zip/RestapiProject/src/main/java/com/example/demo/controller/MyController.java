package com.example.demo.controller;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Customer;
import com.example.demo.service.StuService;

@RestController
@Controller
public class MyController {
	
	
 
	
	@Autowired
	StuService Sservice;
	
	@PostMapping("/add")
	public Customer saveCus(@RequestBody  Customer cus) {
			
    // Customer cus= new Customer(0, "uthai",22);
    
     return this.Sservice.addData(cus);
		
	}
	
	@GetMapping("/getdetails")
	
	public List<Customer>  getdetails(){
		
		return this.Sservice.getdeta();
		
	}
	
	@GetMapping("/getdetails/{id}")
	
	public Optional<Customer>  getOne(@PathVariable (value="id") Integer Identity){
		
		return this.Sservice.getOne(Identity);
		
	}
    @DeleteMapping("/deletedetails/{id}")
	
	public String  getDelete(@PathVariable (value="id") Integer dle){
		
		return this.Sservice.getDelete1(dle);
		
	}
   
    
    @PutMapping("/putdetails/{id}")
    public Customer updatedetails( @PathVariable (value="id") Integer Identity,@RequestBody Customer cus) {
    	
    	
		return this.Sservice.updatedetails(Identity,cus);
    	
    }
	

    
    
	
	
	

}
