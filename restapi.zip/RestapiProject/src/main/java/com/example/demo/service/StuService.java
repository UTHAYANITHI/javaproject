package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Model.Customer;
import com.example.demo.repo.repo;

@Service
public class StuService {
	
	@Autowired
	repo Crepo;
	

	public Customer addData(Customer cus) {
		
		
	  return this.Crepo.save(cus);
	}
	
	
	public List<Customer> getdeta() {
		
		return this.Crepo.findAll();
	}
	
	
    public Optional<Customer> getOne(Integer id) {
		
		return this.Crepo.findById(id);
	}
    
 


	public String getDelete1(Integer id) {
		
		this.Crepo.deleteById(id);
		
		return "successfully deleted";
				
	}
	
	
     public Customer updatedetails(Integer id,Customer cus) {
    	 
    	 Customer  old=this.Crepo.findById(id).orElseThrow();
    	 
          old.setName(cus.getName());
          old.setId(cus.getId());
          old.setAge(cus.getAge());
	      return this.Crepo.save(old);
		

				
	}
	
	

  


	


}
